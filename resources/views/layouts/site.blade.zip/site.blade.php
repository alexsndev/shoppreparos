<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <!-- SEO Meta Tags -->
    <title>@yield('title', 'Shopp Reparos - Soluções Completas em Reparos')</title>
    <meta name="description" content="@yield('description', 'Especialistas em reparos hidráulicos, elétricos e manutenção predial. Qualidade, agilidade e confiança em cada serviço.')">
    <meta name="keywords" content="@yield('keywords', 'reparos, hidráulica, elétrica, manutenção, assistência técnica')">
    <meta name="author" content="Shopp Reparos">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:title" content="@yield('title', 'Shopp Reparos')">
    <meta property="og:description" content="@yield('description')">
    <meta property="og:image" content="{{ asset('img/logohorizontal.png') }}">
    <meta property="og:locale" content="pt_BR">
    
    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="{{ url()->current() }}">
    <meta name="twitter:title" content="@yield('title')">
    <meta name="twitter:description" content="@yield('description')">
    <meta name="twitter:image" content="{{ asset('img/logohorizontal.png') }}">
    
    @stack('meta')
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="{{ asset('img/iconfav.png') }}">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Assets Compilados -->
    <link href="/build/assets/app-BwpZlWD3.css" rel="stylesheet">
    <script src="/build/assets/app-DaBYqt0m.js" defer></script>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'sans': ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
                        'display': ['Poppins', 'system-ui', '-apple-system', 'sans-serif'],
                    },
                    colors: {
                        'primary': {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            200: '#bfdbfe',
                            300: '#93c5fd',
                            400: '#60a5fa',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            800: '#1e40af',
                            900: '#1e3a8a',
                        },
                        'accent': {
                            50: '#f0fdf4',
                            100: '#dcfce7',
                            200: '#bbf7d0',
                            300: '#86efac',
                            400: '#4ade80',
                            500: '#22c55e',
                            600: '#16a34a',
                            700: '#15803d',
                            800: '#166534',
                            900: '#14532d',
                        },
                        'warning': {
                            50: '#fffbeb',
                            100: '#fef3c7',
                            200: '#fde68a',
                            300: '#fcd34d',
                            400: '#fbbf24',
                            500: '#f59e0b',
                            600: '#d97706',
                            700: '#b45309',
                            800: '#92400e',
                            900: '#78350f',
                        },
                        'secondary': {
                            50: '#f8fafc',
                            100: '#f1f5f9',
                            200: '#e2e8f0',
                            300: '#cbd5e1',
                            400: '#94a3b8',
                            500: '#64748b',
                            600: '#475569',
                            700: '#334155',
                            800: '#1e293b',
                            900: '#0f172a',
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.6s ease-out',
                        'scale-in': 'scaleIn 0.3s ease-out',
                        'float': 'float 3s ease-in-out infinite',
                        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                    },
                    keyframes: {
                        fadeIn: {
                            '0%': { opacity: '0' },
                            '100%': { opacity: '1' },
                        },
                        slideUp: {
                            '0%': { transform: 'translateY(30px)', opacity: '0' },
                            '100%': { transform: 'translateY(0)', opacity: '1' },
                        },
                        scaleIn: {
                            '0%': { transform: 'scale(0.9)', opacity: '0' },
                            '100%': { transform: 'scale(1)', opacity: '1' },
                        },
                        float: {
                            '0%, 100%': { transform: 'translateY(0px)' },
                            '50%': { transform: 'translateY(-10px)' },
                        },
                    }
                }
            }
        }
    </script>
    
    <!-- Custom Styles -->
    <style>
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
        }
        
        .font-display {
            font-family: 'Poppins', system-ui, -apple-system, sans-serif;
        }
        
        /* Smooth scrolling */
        html {
            scroll-behavior: smooth;
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f5f9;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        /* Text selection */
        ::selection {
            background-color: #3b82f6;
            color: white;
        }
        
        /* Loading animation */
        .loading-dots {
            display: inline-block;
        }
        
        .loading-dots::after {
            content: '';
            animation: loading-dots 1.5s steps(4, end) infinite;
        }
        
        @keyframes loading-dots {
            0%, 20% { content: ''; }
            40% { content: '.'; }
            60% { content: '..'; }
            80%, 100% { content: '...'; }
        }
        
        /* Glassmorphism effect */
        .glass {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        
        /* Header dropdown animations */
        .dropdown-enter {
            transform: translateY(-10px);
            opacity: 0;
        }
        
        .dropdown-enter-active {
            transform: translateY(0);
            opacity: 1;
            transition: all 0.2s ease-out;
        }
        
        .dropdown-exit {
            transform: translateY(0);
            opacity: 1;
        }
        
        .dropdown-exit-active {
            transform: translateY(-10px);
            opacity: 0;
            transition: all 0.2s ease-in;
        }
    </style>
    
    @stack('styles')
</head>
<body class="bg-gray-50 text-gray-900 antialiased">
    <!-- Header -->
    <header class="bg-white shadow-lg relative z-50">
        <!-- Top Bar -->
        <div class="bg-primary-600 text-white py-2">
            <div class="container mx-auto px-4">
                <div class="flex justify-between items-center text-sm">
                    <div class="flex items-center space-x-4">
                        <span class="hidden md:inline-flex items-center">
                            <i class="fas fa-phone mr-2"></i>
                            (61) 99609-6296 | (61) 99931-8077
                        </span>
                        <span class="hidden sm:inline-flex items-center">
                            <i class="fas fa-envelope mr-2"></i>
                            contato@shoppreparos.com.br
                        </span>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="hidden lg:inline">🕒 Seg - Sex: 8h às 18h | Sáb: 8h às 12h</span>
                        <div class="flex space-x-2">
                            <a href="#" class="hover:text-primary-200 transition-colors">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="hover:text-primary-200 transition-colors">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="#" class="hover:text-primary-200 transition-colors">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Main Header -->
        <div class="container mx-auto px-4">
            <div class="flex items-center justify-between py-4">
                <!-- Logo -->
                <div class="flex items-center">
                    <a href="{{ route('home') }}" class="flex items-center">
                        <img src="{{ asset('img/logohorizontal.png') }}" alt="Shopp Reparos" class="h-12 md:h-16 w-auto">
                    </a>
                </div>
                
                <!-- Navigation -->
                <nav class="hidden lg:flex items-center space-x-8">
                    <a href="{{ route('home') }}" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 relative group">
                        Home
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-600 transition-all duration-200 group-hover:w-full"></span>
                    </a>
                    <a href="/site/produtos" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 relative group">
                        Produtos
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-600 transition-all duration-200 group-hover:w-full"></span>
                    </a>
                    <a href="/site/servicos" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 relative group">
                        Serviços
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-600 transition-all duration-200 group-hover:w-full"></span>
                    </a>
                    <a href="/reparos-hidraulicos" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 relative group">
                        Reparos
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-600 transition-all duration-200 group-hover:w-full"></span>
                    </a>
                    <a href="/assistencia-tecnica" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 relative group">
                        Assistência
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-600 transition-all duration-200 group-hover:w-full"></span>
                    </a>
                    <a href="{{ route('blog.index') }}" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 relative group">
                        Blog
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-600 transition-all duration-200 group-hover:w-full"></span>
                    </a>
                    <a href="/contato" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 relative group">
                        Contato
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-600 transition-all duration-200 group-hover:w-full"></span>
                    </a>
                </nav>
                
                <!-- Action Buttons -->
                <div class="flex items-center space-x-4">
                    <!-- WhatsApp Button -->
                    <a href="https://api.whatsapp.com/send?phone=5561996096296&text=Olá! Vim pelo site!" 
                       class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-full transition-colors duration-200 flex items-center space-x-2 animate-pulse-slow">
                        <i class="fab fa-whatsapp"></i>
                        <span class="hidden md:inline">WhatsApp</span>
                    </a>
                    
                    <!-- Mobile Menu Toggle -->
                    <button id="mobile-menu-toggle" class="lg:hidden p-2 text-gray-600 hover:text-primary-600 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div id="mobile-menu" class="lg:hidden hidden bg-white border-t border-gray-200">
            <div class="container mx-auto px-4 py-4">
                <nav class="flex flex-col space-y-4">
                    <a href="{{ route('home') }}" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2 border-b border-gray-100">
                        Home
                    </a>
                    <a href="/site/produtos" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2 border-b border-gray-100">
                        Produtos
                    </a>
                    <a href="/site/servicos" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2 border-b border-gray-100">
                        Serviços
                    </a>
                    <a href="/reparos-hidraulicos" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2 border-b border-gray-100">
                        Reparos Hidráulicos
                    </a>
                    <a href="/assistencia-tecnica" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2 border-b border-gray-100">
                        Assistência Técnica
                    </a>
                    <a href="{{ route('blog.index') }}" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2 border-b border-gray-100">
                        Blog
                    </a>
                    <a href="/contato" class="text-gray-700 hover:text-primary-600 font-medium transition-colors duration-200 py-2">
                        Contato
                    </a>
                </nav>
            </div>
        </div>
    </header>
    
    <!-- Main Content -->
    <main class="min-h-screen">
        @yield('content')
    </main>
    
    <!-- Footer -->
    <footer class="bg-secondary-900 text-white">
        <div class="container mx-auto px-4 py-12">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <!-- Logo & Info -->
                <div class="lg:col-span-1">
                    <img src="{{ asset('img/logohorizontal.png') }}" alt="Shopp Reparos" class="h-16 w-auto mb-4 brightness-0 invert">
                    <p class="text-gray-300 mb-4">
                        Especialistas em soluções completas para reparos hidráulicos, elétricos e manutenção predial.
                    </p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-facebook-f text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-instagram text-xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-white transition-colors">
                            <i class="fab fa-whatsapp text-xl"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Links Rápidos -->
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-white">Links Rápidos</h3>
                    <ul class="space-y-2">
                        <li><a href="{{ route('home') }}" class="text-gray-300 hover:text-white transition-colors">Home</a></li>
                        <li><a href="/site/produtos" class="text-gray-300 hover:text-white transition-colors">Produtos</a></li>
                        <li><a href="/site/servicos" class="text-gray-300 hover:text-white transition-colors">Serviços</a></li>
                        <li><a href="{{ route('blog.index') }}" class="text-gray-300 hover:text-white transition-colors">Blog</a></li>
                        <li><a href="/contato" class="text-gray-300 hover:text-white transition-colors">Contato</a></li>
                    </ul>
                </div>
                
                <!-- Serviços -->
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-white">Nossos Serviços</h3>
                    <ul class="space-y-2">
                        <li><a href="/reparos-hidraulicos" class="text-gray-300 hover:text-white transition-colors">Reparos Hidráulicos</a></li>
                        <li><a href="/assistencia-tecnica" class="text-gray-300 hover:text-white transition-colors">Assistência Técnica</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition-colors">Manutenção Predial</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition-colors">Instalações Elétricas</a></li>
                    </ul>
                </div>
                
                <!-- Contato -->
                <div>
                    <h3 class="text-lg font-semibold mb-4 text-white">Contato</h3>
                    <div class="space-y-3 text-gray-300">
                        <div class="flex items-start space-x-3">
                            <i class="fas fa-map-marker-alt mt-1 text-primary-400"></i>
                            <div>
                                <p class="font-medium">Águas Claras</p>
                                <p class="text-sm">Q 204 Alfa Mix Loja 15A</p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-3">
                            <i class="fas fa-map-marker-alt mt-1 text-primary-400"></i>
                            <div>
                                <p class="font-medium">Taguatinga</p>
                                <p class="text-sm">St. E Sul CSE 2</p>
                            </div>
                        </div>
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-phone text-primary-400"></i>
                            <p>(61) 99609-6296 | (61) 99931-8077</p>
                        </div>
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-envelope text-primary-400"></i>
                            <p>contato@shoppreparos.com.br</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; {{ date('Y') }} Shopp Reparos. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>
    
    <!-- Floating WhatsApp -->
    <div class="fixed bottom-6 right-6 z-50">
        <a href="https://api.whatsapp.com/send?phone=5561996096296&text=Olá! Vim pelo site!" 
           class="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110 animate-float group">
            <i class="fab fa-whatsapp text-2xl"></i>
            <span class="absolute right-16 top-1/2 transform -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                Fale conosco!
            </span>
        </a>
    </div>
    
    <!-- Scripts -->
    <script>
        // Mobile Menu Toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
            const mobileMenu = document.getElementById('mobile-menu');
            
            mobileMenuToggle.addEventListener('click', function() {
                mobileMenu.classList.toggle('hidden');
            });
            
            // Close mobile menu when clicking outside
            document.addEventListener('click', function(e) {
                if (!mobileMenuToggle.contains(e.target) && !mobileMenu.contains(e.target)) {
                    mobileMenu.classList.add('hidden');
                }
            });
        });
        
        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
        
        // Loading animation helper
        function showLoading(element) {
            element.classList.add('loading-dots');
            element.textContent = 'Carregando';
        }
        
        function hideLoading(element, originalText) {
            element.classList.remove('loading-dots');
            element.textContent = originalText;
        }
        
        // Intersection Observer for animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fade-in');
                }
            });
        }, observerOptions);
        
        // Observe elements with animation classes
        document.querySelectorAll('.animate-on-scroll').forEach(el => {
            observer.observe(el);
        });
    </script>
    
    @stack('scripts')
</body>
</html>
